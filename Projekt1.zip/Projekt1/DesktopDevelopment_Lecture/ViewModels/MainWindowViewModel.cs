﻿using CommunityToolkit.Mvvm.Messaging;
using DesktopDevelopment.ViewModels;
using DesktopDevelopment_Lecture.Helepers;
using DesktopDevelopment_Lecture.Helepers.Messages;
using DesktopDevelopment_Lecture.ViewModels.All;
using DesktopDevelopment_Lecture.ViewModels.Single;
using DesktopDevelopment_Lecture.Views.Single;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace DesktopDevelopment_Lecture.ViewModels
{
    public class MainWindowViewModel : BaseViewModel
    {
        #region TopAndSideMenuCommand

        //public ICommand OpenAddressView { get => new BaseCommand(() => CreateView(new AddressViewModel())); }

        public ICommand OpenAllCustomersViewCommand { get; set; }
        public ICommand OpenNewCustomerViewCommand { get; set; }
        public ICommand OpenAllCountriesViewCommand { get; set; }

        #endregion


        public MainWindowViewModel()
        {
            OpenAllCustomersViewCommand = new BaseCommand(() => CreateListView<CustomersViewModel>());
            OpenAllCountriesViewCommand = new BaseCommand(() => CreateListView<CountriesViewModel>());
            OpenNewCustomerViewCommand = new BaseCommand(() => CreateView(new CustomerViewModel()));
            Commands = new(CreateCommands());
            Workspaces = new();
            Workspaces.CollectionChanged += OnWorkspacesChanged;
            WeakReferenceMessenger.Default.Register<OpenViewMessage>(this, (sender, message) =>
            {
                CreateView(message.WorkspaceToBeOpened);
            });
        }

        #region Buttons in side bar

        public ReadOnlyCollection<CommandViewModel> Commands { get; set; }

        private List<CommandViewModel> CreateCommands()
        {
            return new()
            {
                new CommandViewModel("Customers", OpenAllCustomersViewCommand),
                new CommandViewModel("New customer", OpenNewCustomerViewCommand),
                new CommandViewModel("Countries", OpenAllCountriesViewCommand)
            };
        }

        #endregion

        #region Tabs

        public ObservableCollection<WorkspaceViewModel> Workspaces { get; set; }
        private void OnWorkspacesChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems != null && e.NewItems.Count != 0)
                foreach (WorkspaceViewModel workspace in e.NewItems)
                    workspace.RequestClose += onWorkspaceRequestClose;

            if (e.OldItems != null && e.OldItems.Count != 0)
                foreach (WorkspaceViewModel workspace in e.OldItems)
                    workspace.RequestClose -= onWorkspaceRequestClose;
        }

        private void onWorkspaceRequestClose(object sender, EventArgs e)
        {
            WorkspaceViewModel? workspace = sender as WorkspaceViewModel;
            if (workspace != null)
            {
                Workspaces.Remove(workspace);
            }
        }

        #endregion

        #region Helepers

        private void CreateView(WorkspaceViewModel workspace)
        {
            Workspaces.Add(workspace);
            SetActiveWorkspace(workspace);
        }

        private void CreateListView<WorkspaceViewModelType>() where WorkspaceViewModelType : WorkspaceViewModel, new()
        {
            WorkspaceViewModel? workspace = Workspaces.FirstOrDefault(vm => vm is WorkspaceViewModelType);
            if (workspace == null)
            {
                workspace = new WorkspaceViewModelType();
                Workspaces.Add(workspace);
            }
            SetActiveWorkspace(workspace);
        }

        private void SetActiveWorkspace(WorkspaceViewModel workspace)
        {
            Debug.Assert(Workspaces.Contains(workspace));

            ICollectionView collectionView = CollectionViewSource.GetDefaultView(Workspaces);
            if (collectionView != null)
                collectionView.MoveCurrentTo(workspace);
        }

        #endregion
    }
}
