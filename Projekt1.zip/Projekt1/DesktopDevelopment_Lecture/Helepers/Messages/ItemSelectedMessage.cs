﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Helepers.Messages
{
    public class ItemSelectedMessage<ItemType>
    {
        // item selected on the view
        required public ItemType SelectedItem { get; set; }
        required public object WhoRequestedToSelect { get; set; }
        required public object Sender { get; set; }
    }
}
