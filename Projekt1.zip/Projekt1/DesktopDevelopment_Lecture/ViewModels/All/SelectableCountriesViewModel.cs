﻿using CommunityToolkit.Mvvm.Messaging;
using DesktopDevelopment_Lecture.Dtos.Countries;
using DesktopDevelopment_Lecture.Helepers.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.ViewModels.All
{
    public class SelectableCountriesViewModel : CountriesViewModel
    {
        required public object WhoRequestedToSelect { get; set; }

        public SelectableCountriesViewModel()
        {
            ActionsEnabled = false;
        }

        protected override void HandleSelect()
        {
            if(SelectedItem != null)
            {
                WeakReferenceMessenger.Default.Send(new ItemSelectedMessage<CountryDto>()
                {
                    SelectedItem = SelectedItem,
                    Sender = this,
                    WhoRequestedToSelect = WhoRequestedToSelect
                });
                OnRequestClose();
            }
        }
    }
}
