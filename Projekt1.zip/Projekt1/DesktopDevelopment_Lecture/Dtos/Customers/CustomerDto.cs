﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Dtos.Customers
{
    public class CustomerDto
    {
        required public int Id { get; set; }
        required public string? Code { get; set; }
        required public string? Nip { get; set; }
        required public string Title { get; set; }
        required public string Status { get; set; }
        required public string? Country { get; set; }
    }
}
