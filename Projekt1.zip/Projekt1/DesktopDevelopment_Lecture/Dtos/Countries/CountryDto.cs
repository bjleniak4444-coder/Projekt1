﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Dtos.Countries
{
    public class CountryDto
    {
        required public int Id { get; set; }
        required public string Title { get; set; }
    }
}
