﻿using DesktopDevelopment_Lecture.Dtos.Common;
using DesktopDevelopment_Lecture.Dtos.Customers;
using DesktopDevelopment_Lecture.Helepers;
using DesktopDevelopment_Lecture.Models;
using DesktopDevelopment_Lecture.Models.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Services
{
    public class CustomersService
    {
        public DatabaseContext Database { get; set; }

        public CustomersService()
        {
            Database = new DatabaseContext();
        }

        public List<KeyValueDto> GetStatuses()
        {
            IQueryable<CustomerStatus> statuses = Database.CustomerStatuses.Where(item => item.IsActive);
            IQueryable<KeyValueDto> keyValueDto = statuses.Select(item => new KeyValueDto()
            {
                Key = item.Id,
                Value = item.Title
            });
            return [.. keyValueDto];
        }

        public List<KeyValueDto> GetCategories()
        {
            IQueryable<CustomerCategory> categories = Database.CustomerCategories.Where(item => item.IsActive);
            IQueryable<KeyValueDto> keyValueDto = categories.Select(item => new KeyValueDto()
            {
                Key = item.Id,
                Value = item.Title
            });
            return [.. keyValueDto];
        }

        public List<CustomerDto> GetAllCustomers(FilterOptionsEnum hasNipFilter,
                                                 int? customerStatusId,
                                                 string? searchPhrase)
        {
            IQueryable<Models.Customer> customers = Database.Customers.Where(item => item.IsActive);
            if (customerStatusId != null)
            {
                customers = customers.Where(item => item.CustomerStatusId == customerStatusId);
            }
            if (!string.IsNullOrWhiteSpace(searchPhrase))
            {
                customers = customers.Where(item => item.Id.ToString().Contains(searchPhrase)
                                                    || item.Code!.Contains(searchPhrase)
                                                    || item.Nip!.Contains(searchPhrase)
                                                    || item.Title!.Contains(searchPhrase)
                                                    || item.CustomerStatus.Title.Contains(searchPhrase)
                                                    || item.Address.Country!.Title.Contains(searchPhrase));
            }

            IQueryable<CustomerDto> customerDtos = customers.Select(item => new CustomerDto()
            {
                Id = item.Id,
                Code = item.Code,
                Nip = item.Nip,
                Title = item.Title,
                Status = item.CustomerStatus.Title,
                Country = item.Address.Country!.Title
            });
            if (hasNipFilter == FilterOptionsEnum.Yes)
            {
                customerDtos = customerDtos.Where(item => !string.IsNullOrWhiteSpace(item.Nip));
            }
            else if (hasNipFilter == FilterOptionsEnum.No)
            {
                customerDtos = customerDtos.Where(item => string.IsNullOrWhiteSpace(item.Nip));
            }
            return customerDtos.ToList();
        }

        public CustomerCreateDto InitializeCustomer()
        {
            return new CustomerCreateDto()
            {
                CustomerStatusId = 1,
                CustomerCategoryId = 1,
                CountryId = 1,
                Code = null!,
                CountyOrRegion = null!,
                FlatNumber = null!,
                HouseNumber = null!,
                Nip = null!,
                PhoneNumber = null!,
                PostalCode = null!,
                Street = null!,
                Title = null!,
                PostalCity = null!
            };
        }

        public void Create(CustomerCreateDto customer)
        {
            Database.ChangeTracker.Clear();
            Customer model = new()
            {
                Code = customer.Code,
                CreationDateTime = DateTime.Now,
                CustomerStatusId = customer.CustomerStatusId,
                CustomerCategoryId = customer.CustomerCategoryId,
                IsActive = true,
                Nip = customer.Nip,
                Title = customer.Title,
                Address = new Address()
                {
                    CountryId = customer.CountryId,
                    CountyOrRegion = customer.CountyOrRegion,
                    FlatNumber = customer.FlatNumber,
                    CreationDateTime = DateTime.Now,
                    HouseNumber = customer.HouseNumber,
                    IsActive = true,
                    PhoneNumber = customer.PhoneNumber,
                    PostalCity = customer.PostalCode,
                    PostalCode = customer.PostalCode,
                    Street = customer.Street
                }
            };
            Database.Customers.Add(model);
            Database.SaveChanges();
        }

        private void Raport()
        {
            int customerId = Database.Customers.Where(item => item.IsActive)
                                               .Select(item => item.Id)
                                               .FirstOrDefault();

            DateTime dateFrom = DateTime.Now.AddDays(-14);
            DateTime dateTo = DateTime.Now;

            Database.Customers.Select(item => new
            {
                TotalValueOfAllOrder = item.Invoices.Where(elem => elem.CreationDateTime >= dateFrom && elem.CreationDateTime <= dateTo)
                             .SelectMany(elem => elem.InvoiceItems)
                             .Sum(elem => (double)elem.BasePricePerUnit * elem.Quantity * (elem.TaxRate / 100))
            });
        }
    }
}
