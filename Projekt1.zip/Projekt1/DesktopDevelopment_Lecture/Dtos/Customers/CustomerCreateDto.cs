﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Dtos.Customers
{
    public class CustomerCreateDto
    {
        required public string? Code { get; set; }
        required public string? Nip { get; set; }
        required public string Title { get; set; } = null!;
        required public int CustomerStatusId { get; set; }
        required public int CustomerCategoryId { get; set; }
        required public string? Street { get; set; }
        required public string? HouseNumber { get; set; }
        required public string? FlatNumber { get; set; }
        required public string? PostalCode { get; set; }
        required public string? PostalCity { get; set; }
        required public string? CountyOrRegion { get; set; }
        required public int? CountryId { get; set; }
        required public string? PhoneNumber { get; set; }
    }
}
