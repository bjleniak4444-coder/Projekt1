﻿using DesktopDevelopment_Lecture.Dtos.Countries;
using DesktopDevelopment_Lecture.Dtos.Customers;
using DesktopDevelopment_Lecture.Models.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Services
{
    public class CountriesService
    {
        public DatabaseContext Database { get; set; }

        public CountriesService()
        {
            Database = new DatabaseContext();
        }

        public List<CountryDto> GetAllCountries()
        {
            IQueryable<Models.Country> countries = Database.Countries.Where(item => item.IsActive);
            IQueryable<CountryDto> ContryDtos = countries.Select(item => new CountryDto()
            {
                Id = item.Id,
                Title = item.Title
            });
            return [.. ContryDtos];
        }

    }
}
