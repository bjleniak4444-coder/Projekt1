﻿using DesktopDevelopment_Lecture.ViewModels;
using DesktopDevelopment_Lecture.Views;
using System.Configuration;
using System.Data;
using System.Windows;

namespace DesktopDevelopment_Lecture
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            Thread.CurrentThread.CurrentCulture = new("pl");
            Thread.CurrentThread.CurrentUICulture= new("pl");

            MainWindow mainWindow = new();
            MainWindowViewModel mainWindowViewModel = new();
            mainWindow.DataContext = mainWindowViewModel;
            MainWindow = mainWindow;
            mainWindow.Show();
        }
    }

}
