﻿using DesktopDevelopment.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Helepers.Messages
{
    public class OpenViewMessage
    {
        required public WorkspaceViewModel WorkspaceToBeOpened { get; set; }
    }
}
