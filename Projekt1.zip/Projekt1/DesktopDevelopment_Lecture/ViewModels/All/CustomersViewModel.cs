﻿using CommunityToolkit.Mvvm.Input;
using DesktopDevelopment.ViewModels;
using DesktopDevelopment_Lecture.Dtos.Common;
using DesktopDevelopment_Lecture.Dtos.Customers;
using DesktopDevelopment_Lecture.Helepers;
using DesktopDevelopment_Lecture.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DesktopDevelopment_Lecture.ViewModels.All
{
    public class CustomersViewModel : WorkspaceViewModel
    {
        public List<KeyValueDto> NoFilterYesNoOptions { get; set; }

        public List<KeyValueDto> CustomerStatusesFilterOptions { get; set; }

        private int _CustomerStatusesFilter;
        public int CustomerStatusesFilter
        {
            get => _CustomerStatusesFilter;
            set
            {
                if (_CustomerStatusesFilter != value)
                {
                    _CustomerStatusesFilter = value;
                    OnPropertyChanged(() => CustomerStatusesFilter);
                }
            }
        }

        private int _HasNipFilter;
        public int HasNipFilter
        {
            get => _HasNipFilter;
            set
            {
                if (_HasNipFilter != value)
                {
                    _HasNipFilter = value;
                    OnPropertyChanged(() => HasNipFilter);
                }
            }
        }

        private string? _SearchPhrase;
        public string? SearchPhrase
        {
            get => _SearchPhrase;
            set
            {
                if (_SearchPhrase != value)
                {
                    _SearchPhrase = value;
                    OnPropertyChanged(() => SearchPhrase);
                }
            }
        }

        public ICommand RefreshCommand { get; set; }

        public RelayCommand<CustomerDto> EditCommand { get; set; }
        public CustomersService Service { get; }
        public ObservableCollection<CustomerDto> Models { get; }

        private CustomerDto? _SelectedItem;
        public CustomerDto? SelectedItem
        {
            get => _SelectedItem;
            set
            {
                if (_SelectedItem != value)
                {
                    _SelectedItem = value;
                    OnPropertyChanged(() => SelectedItem);
                }
            }
        }

        public CustomersViewModel()
        {
            DisplayName = "Customers";
            Service = new CustomersService();
            RefreshCommand = new BaseCommand(() => Refresh());
            EditCommand = new RelayCommand<CustomerDto>((customer) => Edit(customer));
            NoFilterYesNoOptions = new List<KeyValueDto>()
            {
                new() { Key = ((int)FilterOptionsEnum.NoFilter), Value = "No filter" },
                new() { Key = ((int)FilterOptionsEnum.Yes), Value = "Yes" },
                new() { Key = ((int)FilterOptionsEnum.No), Value = "No" },
            };
            CustomerStatusesFilterOptions = Service.GetStatuses();
            CustomerStatusesFilter = (int)FilterOptionsEnum.NoFilter;
            CustomerStatusesFilterOptions.Insert(0, new KeyValueDto()
            { Key = (int)FilterOptionsEnum.NoFilter , Value = "No filter"});
            _HasNipFilter = (int)FilterOptionsEnum.NoFilter;
            int? customerStatusId = 
                CustomerStatusesFilter == ((int)FilterOptionsEnum.NoFilter) ? null : CustomerStatusesFilter;
            Models = new ObservableCollection<CustomerDto>(Service.GetAllCustomers((FilterOptionsEnum)_HasNipFilter,
                                                                                   customerStatusId,
                                                                                   SearchPhrase));
        }

        private void Refresh()
        {
            int? customerStatusId =
                CustomerStatusesFilter == ((int)FilterOptionsEnum.NoFilter) ? null : CustomerStatusesFilter;
            Models.Clear();
            Service.GetAllCustomers((FilterOptionsEnum)_HasNipFilter, customerStatusId, SearchPhrase).ForEach(item => Models.Add(item));
        }

        private void Edit(CustomerDto? customer)
        {

        }
    }
}
