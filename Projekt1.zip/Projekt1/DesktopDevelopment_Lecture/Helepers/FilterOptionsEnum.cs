﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesktopDevelopment_Lecture.Helepers
{
    public enum FilterOptionsEnum
    {
        NoFilter = -1,
        Yes = 1,
        No = 2
    }
}
