﻿using CommunityToolkit.Mvvm.Input;
using DesktopDevelopment.ViewModels;
using DesktopDevelopment_Lecture.Dtos.Countries;
using DesktopDevelopment_Lecture.Dtos.Customers;
using DesktopDevelopment_Lecture.Helepers;
using DesktopDevelopment_Lecture.Resources.Strings;
using DesktopDevelopment_Lecture.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DesktopDevelopment_Lecture.ViewModels.All
{
    public class CountriesViewModel : WorkspaceViewModel
    {
        public bool ActionsEnabled { get; set; }

        public ICommand RefreshCommand { get; set; }
        public CountriesService Service { get; }
        public ObservableCollection<CountryDto> Models { get; }

        private CountryDto? _SelectedItem;
        public CountryDto? SelectedItem
        {
            get => _SelectedItem;
            set
            {
                if (_SelectedItem != value)
                {
                    _SelectedItem = value;
                    HandleSelect();
                    OnPropertyChanged(() => SelectedItem);
                }
            }
        }

        public CountriesViewModel()
        {
            DisplayName = GlobalResources.Countries;
            Service = new CountriesService();
            Models = new ObservableCollection<CountryDto>(Service.GetAllCountries());
            RefreshCommand = new BaseCommand(() => Refresh());
            ActionsEnabled = true;
        }

        private void Refresh()
        {
            Models.Clear();
            Service.GetAllCountries().ForEach(item => Models.Add(item));
        }

        virtual protected void HandleSelect() { }
    }
}
