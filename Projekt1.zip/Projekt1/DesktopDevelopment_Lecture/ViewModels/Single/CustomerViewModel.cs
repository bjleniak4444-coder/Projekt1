﻿using CommunityToolkit.Mvvm.Messaging;
using DesktopDevelopment.ViewModels;
using DesktopDevelopment_Lecture.Dtos.Common;
using DesktopDevelopment_Lecture.Dtos.Countries;
using DesktopDevelopment_Lecture.Dtos.Customers;
using DesktopDevelopment_Lecture.Helepers;
using DesktopDevelopment_Lecture.Helepers.Messages;
using DesktopDevelopment_Lecture.Services;
using DesktopDevelopment_Lecture.ViewModels.All;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace DesktopDevelopment_Lecture.ViewModels.Single
{
    public class CustomerViewModel : WorkspaceViewModel, IDataErrorInfo
    {
        private readonly CustomersService service;
        public ICommand CreateCommand { get; set; }
        public CustomerCreateDto Model { get; set; }

        private ObservableCollection<KeyValueDto> _Statuses;
        public ObservableCollection<KeyValueDto> Statuses
        {
            get => _Statuses;
            set
            {
                if (value != _Statuses)
                {
                    _Statuses = value;
                    OnPropertyChanged(() => Statuses);
                }
            }
        }

        private KeyValueDto? _SelectedStatus;
        public KeyValueDto? SelectedStatus
        {
            get => _SelectedStatus;
            set
            {
                if (value != _SelectedStatus)
                {
                    _SelectedStatus= value;
                    OnPropertyChanged(() => SelectedStatus);
                }
            }
        }

        private ObservableCollection<KeyValueDto> _Categories;
        public ObservableCollection<KeyValueDto> Categories
        {
            get => _Categories;
            set
            {
                if (value != _Categories)
                {
                    _Categories= value;
                    OnPropertyChanged(() => Categories);
                }
            }
        }

        public string? Code
        {
            get => Model.Code;
            set
            {
                if (Model.Code != value)
                {
                    Model.Code = value;
                    OnPropertyChanged(() => Code);
                }
            }
        }

        public string? Nip
        {
            get => Model.Nip;
            set
            {
                if (Model.Nip != value)
                {
                    Model.Nip = value;
                    OnPropertyChanged(() => Nip);
                }
            }
        }

        public string Title
        {
            get => Model.Title;
            set
            {
                if (Model.Title != value)
                {
                    Model.Title = value;
                    OnPropertyChanged(() => Title);
                }
            }
        }

        public int CustomerStatusId
        {
            get => Model.CustomerStatusId;
            set
            {
                if (Model.CustomerStatusId != value)
                {
                    Model.CustomerStatusId = value;
                    OnPropertyChanged(() => CustomerStatusId);
                }
            }
        }

        public int CustomerCategoryId
        {
            get => Model.CustomerCategoryId;
            set
            {
                if (Model.CustomerCategoryId != value)
                {
                    Model.CustomerCategoryId = value;
                    OnPropertyChanged(() => CustomerCategoryId);
                }
            }
        }

        public string? Street
        {
            get => Model.Street;
            set
            {
                if (Model.Street != value)
                {
                    Model.Street = value;
                    OnPropertyChanged(() => Street);
                }
            }
        }

        public string? HouseNumber
        {
            get => Model.HouseNumber;
            set
            {
                if (Model.HouseNumber != value)
                {
                    Model.HouseNumber = value;
                    OnPropertyChanged(() => HouseNumber);
                }
            }
        }

        public string? FlatNumber
        {
            get => Model.FlatNumber;
            set
            {
                if (Model.FlatNumber != value)
                {
                    Model.FlatNumber = value;
                    OnPropertyChanged(() => FlatNumber);
                }
            }
        }

        public string? PostalCode
        {
            get => Model.PostalCode;
            set
            {
                if (Model.PostalCode != value)
                {
                    Model.PostalCode = value;
                    OnPropertyChanged(() => PostalCode);
                }
            }
        }

        public string? PostalCity
        {
            get => Model.PostalCity;
            set
            {
                if (Model.PostalCity != value)
                {
                    Model.PostalCity = value;
                    OnPropertyChanged(() => PostalCity);
                }
            }
        }

        public string? CountyOrRegion
        {
            get => Model.CountyOrRegion;
            set
            {
                if (Model.CountyOrRegion != value)
                {
                    Model.CountyOrRegion = value;
                    OnPropertyChanged(() => CountyOrRegion);
                }
            }
        }

        public int? CountryId
        {
            get => Model.CountryId;
            set
            {
                if (Model.CountryId != value)
                {
                    Model.CountryId = value;
                    OnPropertyChanged(() => CountryId);
                }
            }
        }

        public string? PhoneNumber
        {
            get => Model.PhoneNumber;
            set
            {
                if (Model.PhoneNumber != value)
                {
                    Model.PhoneNumber = value;
                    OnPropertyChanged(() => PhoneNumber);
                }
            }
        }

        private bool _IncludeAddressData;
        public bool IncludeAddressData
        {
            get => _IncludeAddressData;
            set
            {
                if (_IncludeAddressData != value)
                {
                    _IncludeAddressData = value;
                    OnPropertyChanged(() => IncludeAddressData);
                }
            }
        }

        public ICommand SelectCountryCommand { get; set; }

        private string _SelectCountryButtonText;
        public string SelectCountryButtonText
        {
            get => _SelectCountryButtonText;
            set
            {
                if (_SelectCountryButtonText != value)
                {
                    _SelectCountryButtonText = value;
                    OnPropertyChanged(() => SelectCountryButtonText);
                }
            }
        }

        public CustomerViewModel()
        {
            _SelectCountryButtonText = "Select country";
            DisplayName = "Customer";
            service = new CustomersService();
            Model = service.InitializeCustomer();
            CreateCommand = new BaseCommand(() => Create());
            _Statuses = new ObservableCollection<KeyValueDto>(service.GetStatuses());
            _Categories = new ObservableCollection<KeyValueDto>(service.GetCategories());
            SelectedStatus = Statuses.FirstOrDefault();
            SelectCountryCommand = new BaseCommand(() => SelectCountry());
            WeakReferenceMessenger.Default.Register<ItemSelectedMessage<CountryDto>>(this,
                (sender, message) => ReceiveCountry(message));
        }

        private void ReceiveCountry(ItemSelectedMessage<CountryDto> message)
        {
            if(message.WhoRequestedToSelect == this)
            {
                CountryId = message.SelectedItem.Id;
                SelectCountryButtonText = message.SelectedItem.Title;
            }
        }

        private void Create()
        {
            try
            {
                Model.CustomerStatusId = SelectedStatus.Key;
                service.Create(Model);
                OnRequestClose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during save operation", "Error");
            }
        }

        private void SelectCountry()
        {
            WeakReferenceMessenger.Default.Send(new OpenViewMessage()
            {
                WorkspaceToBeOpened = new SelectableCountriesViewModel()
                {
                    WhoRequestedToSelect = this
                }
            });
        }

        public string Error => string.Empty;

        public string this[string columnName] => ValidateProperty(columnName);

        virtual public string ValidateProperty(string propertyName) {
            if (propertyName == nameof(Title))
            {
                if (string.IsNullOrWhiteSpace(Title))
                {
                    return "This field is required";
                }
            }
            else if(propertyName == nameof(Nip))
            {
                if(Nip?.Length != 10)
                {
                    return "This field should contain 10 numbers";
                }
            }
            return string.Empty;
        }
    }
}
